package model;

public class LockException extends Exception {
    public LockException(String message) {
        super(message);
    }
}
